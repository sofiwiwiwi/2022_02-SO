(￣▽￣)/
⭐Javier Antonio Pérez Pinto - 202004533-k⭐
⭐Sofía Isidora Riquelme Flores - 202073615-4⭐

‿︵‿︵‿︵‿ヽ(°□° )ノ︵‿︵‿︵‿︵

✨Instrucciones:
La tarea se compone de lo siguiente:
	- archivos (carpeta donde se encuentran los archivos a ordenar)
	- orden.c
	- visualizacion.c
	- makefile
Para la compilacion de ambos programas, abrir la consola en una carpeta con todo lo mencionado anteriormente y ejecutar el comando:
	make all
Luego para la ejecución de orden.c ejecutar:
	make orden
Y para la posterior ejecución de visualizacion.c ejecutar:
	make visualizacion
Si desea devolver los archivos a su carpeta original y eliminar los archivos creados durante el proceso de compilación, ejecutar:
	make clean

‿︵‿︵‿︵‿ヽ(°□° )ノ︵‿︵‿︵‿︵

✨Consideraciones:
- Todos los archivos a ordenar deben estar dentro de una carpeta llamada archivos
- Dado el contexto de la tarea, se asume que todos los alumnos tendrán una prioridad de al menos 3000.
- Si no hay ningún estudiante con cierta prioridad o cierto año de ingreso no se creará la carpeta. Es decir, si por ejemplo no hay ningún estudiante con más de 9000 
de prioridad que haya entrado el 2019, la carpeta 9000+ no se creará en ese año. 
- Se asume que siempre se ejecutará el programa visualizacion.c después de ejecutar orden.c