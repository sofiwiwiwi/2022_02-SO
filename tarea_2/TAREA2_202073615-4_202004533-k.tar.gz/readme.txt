(*≧ω≦*)  Integrantes: 
	Sofía Riquelme Flores
		Paralelo 200
		Rol 202073615-4
	Javier Pérez Pinto
		Paralelo 200
		Rol 202004533-k

🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟

<(￣︶￣)> Supuestos y consideraciones:

	+ los inputs son válidos, hay un poco de detección de errores como índices inválidos y cosas por el estilo, pero no funcionan aun del todo correcto y 100% probados

	+ no hay piezas repetidas (es decir se juega con solo un "mazo" de dominó)

	+ los bots, para términos de revision igual imprimirán su mano por consola antes de colocar la respectiva pieza, así como el tablero, sólo no se pedirán los inputs

	+ por términos de simpleza el jugador número 1 sera siempre el que controlemos

	+para mejor legibilidad se trunca el tamaño del tablero a 8 (mostrando los ultimos 4 a la izquierda y derecha) denotando lo siguiente
	una linea de | para cuando no se muestra una pieza
	una linea de || para cuando no se muestran dos o más piezas


🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟

＼(٥⁀▽⁀ )／ Instrucciones:

La tarea se compone de los siguientes archivos:
	funciones.c
	funciones.h
	main.c
	makefile

Para compilar la tarea, abrir una consola con todo lo mencionado anteriormente y correr el comando:
	make compile
y para su posterior ejecución, correr:
	make run
Luego, si desea eliminar los archivos creados durante la compilación, ejecutar:
	make clean