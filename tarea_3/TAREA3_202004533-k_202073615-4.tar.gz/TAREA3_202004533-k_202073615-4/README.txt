( ˘▽˘)っ♨
⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩
Integrantes:
    ⭐Javier Antonio Pérez Pinto - 202004533-k⭐
    ⭐Sofía Isidora Riquelme Flores - 202073615-4⭐

⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩⋆｡°✩

ฅ^•ﻌ•^ฅ  
Instrucciones:
    Para el testear con un solo archivo, correr en la consola el siguiente comando:
        make run 
    donde informe-nautico es el archivo que contiene el mapa de la embarcacion

    Luego, para facilitar el testeo con múltiples archivos, se creó el programa test_generator.py. Para utilizarlo, debe correr el comando
        python3 test_generator.py
    y luego ingresar el valor de N y M respectivamente. Esto generará archivos con todas las posiciones posibles del barquito.
    Para probar con múltiples archivos de una sola vez, se creó un script de bash llamado run_test.sh. Para correrlo, se debe utilizar el comando:
        ./run_test.sh
    Esto se hizo con la finalidad de crear el excel, y para facilitar el testeo de la tarea.

    Si desea borrar los archivos class y los txt generados puede correr el comando make clean, pero se va a borrar el readme y el informe náutico también (no supe arreglar esto)