for file in *.txt
do
  make run FILE=$file
done